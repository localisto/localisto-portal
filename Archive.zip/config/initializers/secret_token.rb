# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Localisto::Application.config.secret_token = 'fe1ebeb1e3351ad1b406e50114e4a021c14a28996d3cb3cd7eda885a3e25a7a9de6ae4f7b18df768c40919985bb0f7be0e3b03b945715acc814b84331e560445'
