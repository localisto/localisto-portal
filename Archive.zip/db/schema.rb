# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 0) do

  create_table "agency", :force => true do |t|
    t.string  "name",                                            :null => false
    t.integer "included_by_default", :limit => 1, :default => 0, :null => false
    t.integer "sort_order",          :limit => 2, :default => 0, :null => false
  end

  create_table "answer", :force => true do |t|
    t.integer "question_id",                :null => false
    t.string  "image"
    t.text    "description"
    t.integer "sort_order",  :default => 0, :null => false
  end

  add_index "answer", ["question_id"], :name => "question_id"

  create_table "project", :force => true do |t|
    t.integer   "agency_id",                            :null => false
    t.text      "description",                          :null => false
    t.text      "location",         :limit => 16777215
    t.text      "display_location", :limit => 16777215
    t.timestamp "created_at",                           :null => false
  end

  add_index "project", ["agency_id"], :name => "agency_id"

  create_table "project_image", :force => true do |t|
    t.integer "project_id", :null => false
    t.string  "image",      :null => false
  end

  add_index "project_image", ["project_id", "image"], :name => "project_id", :unique => true

  create_table "question", :force => true do |t|
    t.string  "type",        :limit => 0,                :null => false
    t.string  "image"
    t.text    "description"
    t.integer "aoi_id"
    t.integer "sort_order",  :limit => 2, :default => 0, :null => false
  end

  create_table "user", :force => true do |t|
    t.string "username",                :null => false
    t.string "email",                   :null => false
    t.string "password", :limit => 100, :null => false
    t.string "salt",     :limit => 100, :null => false
  end

  add_index "user", ["username"], :name => "username", :unique => true

  create_table "user_agency", :force => true do |t|
    t.integer "user_id",                   :null => false
    t.integer "agency_id",                 :null => false
    t.integer "sort_order", :default => 0, :null => false
  end

  add_index "user_agency", ["agency_id"], :name => "agency_id"
  add_index "user_agency", ["user_id", "agency_id"], :name => "user_id", :unique => true

  create_table "user_answer", :force => true do |t|
    t.integer "user_id",   :null => false
    t.integer "answer_id", :null => false
  end

  add_index "user_answer", ["answer_id"], :name => "answer_id"
  add_index "user_answer", ["user_id"], :name => "user_id"

end
