class Agency < ActiveRecord::Base
   has_many :projects, :dependent => :destroy
   set_table_name "agency"
   attr_accessible :included_by_default, :name, :sort_order
end
