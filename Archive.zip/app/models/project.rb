
class Project < ActiveRecord::Base
	belongs_to :agency
	set_table_name "project"
  attr_accessible :agency_id, :display_title, :time, :date, :description, :display_location, :location
end
