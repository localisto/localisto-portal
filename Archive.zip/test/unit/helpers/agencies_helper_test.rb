require 'test_helper'

class AgenciesHelperTest < ActionView::TestCase
end
